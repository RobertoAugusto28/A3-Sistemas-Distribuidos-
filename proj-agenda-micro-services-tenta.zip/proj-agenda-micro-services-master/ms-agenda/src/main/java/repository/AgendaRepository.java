package repository;

public interface AgendaRepository {
}
