package service;

public class InfAgendaDTO {
}
