package aula.agenda.msagenda.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;

import aula.agenda.msagenda.controller.dto.AgendaDTO;
import aula.agenda.msagenda.model.Agenda;
import aula.agenda.msagenda.repository.AgendaRepository;
import org.springframework.web.client.RestTemplate;

@Service
public class AgendaService {

    @Autowired
    private static AgendaRepository agendaRepository;
    @Autowired
    private RestTemplate restTemplate;



    public void save(AgendaDTO dto) {

        //consult serviço funcinario
        //verificar se funcionário existe
        //consultar serviço sala
        //verificase a sala existe
        //se todas as informações estiverem ok
        Agenda agenda = dto.converteParaAgenda();
        agendaRepository.save(agenda);

    }

    public List<AgendaDTO> listarAgendas() {
        List<Agenda> agendaList = agendaRepository.findAll();
        List<AgendaDTO> dtoList = new ArrayList<>();
        for (Agenda agenda : agendaList) {
            AgendaDTO agendaDTO = new AgendaDTO(agenda);
            //onsultar serviço funcinario
            // consultar serviço sala*/

            dtoList.add(agendaDTO);
        }
        return dtoList;
    }
}