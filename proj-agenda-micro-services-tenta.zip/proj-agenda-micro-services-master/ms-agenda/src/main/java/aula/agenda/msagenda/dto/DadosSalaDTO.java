package aula.agenda.msagenda.dto;

public class DadosSalaDTO {
}
