package aula.agenda.msagenda.dto;

import aula.agenda.msagenda.model.Agenda;
import aula.agenda.msagenda.model.AgendaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import service.AgendaService;
//import aula.agenda.msagenda.service.AgendaService;
import java.util.List;

@RestController
@RequestMapping("/agenda")
public class AgendaControler {
    @Autowired
    private AgendaService agendaService;
    @Autowired
    private AgendaRepository agendaRepository;

    @GetMapping("/")
    public List<Agenda>listaTodasAgendas(){
        return agendaService();
    }

    private List<Agenda> agendaService() {
    }

    @PostMapping("/")
    public void inserirAgenda(@RequestBody Agenda agenda){ agendaRepository.save(agenda)}
}
